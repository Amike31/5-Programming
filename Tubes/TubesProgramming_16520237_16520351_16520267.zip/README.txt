link Tubes : https://github.com/Amike31/5-Programming/blob/main/TubesProgramming_16520237_16520351_16520267.c

link repository : https://github.com/Amike31/5-Programming.git

Cara menjalankan program :
1. Buka program "TubesProgramming_16520237_16520351_16520267.exe" dengan command promp atau terminal lain. Bisa juga dari terminal IDE.
   Atau buka source code "TubesProgramming_16520237_16520351_16520267.c" dengan compiler.
2. Ikuti instruksi dari program.
3. Selamat mencoba..!

Folder Docs berisi dokumentasi hasil program saat dijalankan.
Folder Src berisi soucre code dan program.